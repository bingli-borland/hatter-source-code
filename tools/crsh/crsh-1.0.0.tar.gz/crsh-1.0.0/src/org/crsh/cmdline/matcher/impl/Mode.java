package org.crsh.cmdline.matcher.impl;

/**
* @author <a href="mailto:julien.viet@exoplatform.com">Julien Viet</a>
*/
public enum Mode {

  INVOKE,

  COMPLETE

}
