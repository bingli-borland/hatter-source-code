package org.crsh.cmdline.matcher.tokenizer;

/**
 * @author <a href="mailto:julien.viet@exoplatform.com">Julien Viet</a>
 */
enum Status {

  INIT,

  WORD,

  SHORT_OPTION,

  LONG_OPTION

}
