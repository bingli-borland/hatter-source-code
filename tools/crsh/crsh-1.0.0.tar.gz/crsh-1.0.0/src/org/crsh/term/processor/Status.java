package org.crsh.term.processor;

/** @author <a href="mailto:julien.viet@exoplatform.com">Julien Viet</a> */
enum Status {

  AVAILABLE,

  PROCESSING,

  CANCELLING,

  CLOSED

}
