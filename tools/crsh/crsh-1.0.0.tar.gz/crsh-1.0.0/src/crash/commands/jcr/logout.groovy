if (session != null)
{
  session.logout();
  currentPath = null;
}